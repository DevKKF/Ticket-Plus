<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Liste des sites</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 11px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 6px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
            font-size: 18px;
        }
        .page-number {
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            font-size: 10px;
            padding: 10px;
        }
        .page-break {
            page-break-after: always;
        }
        .header {
            position: fixed;
            top: 0;
            width: 100%;
            text-align: center;
            padding: 10px;
            text-transform: uppercase;
        }
        .text-center {
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Liste des sites</h1>
    </div>
    <br><br><br><br><br>

    <table>
        <thead>
            <tr>
                <th class="text-center" style="width: 3%">N°</th>
                <th class="text-center" style="width: 8%">Site IHS</th>
                <th class="text-center" style="width: 12%">Site Name</th>
                <th class="text-center" style="width: 8%">Région</th>
                <th class="text-center" style="width: 8%">Zone</th>
                <th class="text-center" style="width: 8%">Opérateur</th>
                <th class="text-center" style="width: 8%">Priority IHS</th>
                <th class="text-center" style="width: 15%">Topology / Typology</th>
                <th class="text-center" style="width: 5%">SBC</th>
            </tr>
        </thead>
        <tbody>
            @foreach($sites as $key => $site)
            <tr>
                <td class="text-center">{{ $key + 1 }}</td>
                <td>{{ $site->site_ihs }}</td>
                <td>{{ $site->site_nom }}</td>
                <td>{{ $site->region_nom }}</td>
                <td>{{ $site->zone_nom }}</td>
                <td>{{ $site->operateur_nom }}</td>
                <td>{{ $site->priorite_ihs_nom }}</td>
                <td>{{ $site->topologie_typologie_nom }}</td>
                <td class="text-center">{{ $site->site_sbc }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>

    <script type="text/php">
        if (isset($pdf)) {
            $text = "Page {PAGE_NUM} / {PAGE_COUNT}";
            $size = 10;
            $font = $fontMetrics->getFont("Arial");
            $width = $fontMetrics->get_text_width($text, $font, $size) / 2;
            $x = ($pdf->get_width() - $width) / 2;
            $y = $pdf->get_height() - 35;
            $pdf->page_text($x, $y, $text, $font, $size);
        }
    </script>
</body>
</html> 