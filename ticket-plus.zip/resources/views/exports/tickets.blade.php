<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Liste des tickets</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 11px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 6px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
            font-size: 18px;
        }
        .page-number {
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            font-size: 10px;
            padding: 10px;
        }
        .page-break {
            page-break-after: always;
        }
        .header {
            position: fixed;
            top: 0;
            width: 100%;
            text-align: center;
            padding: 10px;
            text-transform: uppercase;
        }
        .text-center{
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Liste des tickets</h1>
    </div>
    <br><br><br><br><br>

    <table>
        <thead>
            <tr>
                <th class="text-center" style="width: 3%">N°</th>
                <th class="text-center" style="width: 6%">Site IHS</th>
                <th class="text-center" style="width: 10%">Site Name</th>
                <th class="text-center" style="width: 3%">Type</th>
                <th class="text-center" style="width: 12%">Chef d'équipe / Technicien</th>
                <th class="text-center" style="width: 6%">Date début</th>
                <th class="text-center" style="width: 7%">Heure début</th>
                <th class="text-center" style="width: 10%">Type d'action</th>
                <th class="text-center" style="width: 15%">Tâches</th>
                <th class="text-center" style="width: 6%">Date fin</th>
                <th class="text-center" style="width: 7%">Heure fin</th>
            </tr>
        </thead>
        <tbody>
            @foreach($tickets as $key => $ticket)
            <tr>
                <td>{{ $key + 1 }}</td>
                <td>{{ $ticket->site_ihs }}</td>
                <td>{{ $ticket->site_nom }}</td>
                <td>{{ $ticket->site_sbc }}</td>
                <td>{{ $ticket->nom_prenoms }}</td>
                <td>{{ $ticket->ticket_datedebut }}</td>
                <td>{{ $ticket->ticket_heuredebut }}</td>
                <td>{{ $ticket->type_action_nom }}</td>
                <td>{{ $ticket->ticket_tacherealisee }}</td>
                <td>{{ $ticket->ticket_datefin }}</td>
                <td>{{ $ticket->ticket_heurefin }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>

    <script type="text/php">
        if (isset($pdf)) {
            $text = "Page {PAGE_NUM} / {PAGE_COUNT}";
            $size = 10;
            $font = $fontMetrics->getFont("Arial");
            $width = $fontMetrics->get_text_width($text, $font, $size) / 2;
            $x = ($pdf->get_width() - $width) / 2;
            $y = $pdf->get_height() - 35;
            $pdf->page_text($x, $y, $text, $font, $size);
        }
    </script>
</body>
</html> 